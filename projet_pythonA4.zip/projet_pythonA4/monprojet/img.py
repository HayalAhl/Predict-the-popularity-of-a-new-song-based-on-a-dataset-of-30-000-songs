# -*- coding: latin-1 -*-
import os
import django
from django.core.files import File  # Importez File ici

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'monprojet.settings')
django.setup()

from monapp.models import MonModele

chemin_image = 'media\\images\\newplot.png'

with open(chemin_image, 'rb') as file:
    image_content = file.read()

image_file = File(image_content, name='newplot.png')
mon_modele = MonModele.objects.create(image=image_file)
