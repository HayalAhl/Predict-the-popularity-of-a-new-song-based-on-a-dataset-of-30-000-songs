# forms.py
from django import forms

class FilterForm(forms.Form):
    track_id = forms.BooleanField(initial=True, required=False)
    track_name = forms.BooleanField(initial=True, required=False)
    track_artist = forms.BooleanField(initial=True, required=False)
    track_popularity = forms.BooleanField(initial=True, required=False)
    track_album_id = forms.BooleanField(initial=True, required=False)
    track_album_name = forms.BooleanField(initial=True, required=False)
    track_album_release_date = forms.BooleanField(initial=True, required=False)
    #playlist_name = forms.BooleanField(initial=True, required=False)
    #playlist_id = forms.BooleanField(initial=True, required=False)
    #playlist_genre = forms.BooleanField(initial=True, required=False)
    #playlist_subgenre = forms.BooleanField(initial=True, required=False)
    danceability = forms.BooleanField(initial=True, required=False)
    energy = forms.BooleanField(initial=True, required=False)
    key = forms.BooleanField(initial=True, required=False)
    loudness = forms.BooleanField(initial=True, required=False)
    mode = forms.BooleanField(initial=True, required=False)
    speechiness = forms.BooleanField(initial=True, required=False)
    acousticness = forms.BooleanField(initial=True, required=False)
    instrumentalness = forms.BooleanField(initial=True, required=False)
    liveness = forms.BooleanField(initial=True, required=False)
    valence = forms.BooleanField(initial=True, required=False)
    tempo = forms.BooleanField(initial=True, required=False)
    duration_ms = forms.BooleanField(initial=True, required=False)

class SearchForm(forms.Form):
    track_name = forms.CharField(label='Track Name Search', required=False, widget=forms.TextInput(attrs={'class': 'form-control'}))
    track_id = forms.CharField(label='Track ID Search', required=False, widget=forms.TextInput(attrs={'class': 'form-control'}))
    track_artist = forms.CharField(label='Track Artist Search', required=False, widget=forms.TextInput(attrs={'class': 'form-control'}))
    popularity = forms.IntegerField(label='Popularity Search', required=False, widget=forms.NumberInput(attrs={'class': 'form-control'}))


