# monapp/models.py
from django.db import models

class Song(models.Model):
    title = models.CharField(max_length=255)
    artist = models.CharField(max_length=255)
    date = models.DateField()
    duration = models.FloatField()
    genre = models.CharField(max_length=255)
    subgenre = models.CharField(max_length=255)
    danceability = models.FloatField()
    energy = models.FloatField()
    key = models.IntegerField()
    loudness = models.FloatField()
    mode = models.IntegerField()
    speechiness = models.FloatField()
    acousticness = models.FloatField()
    instrumentalness = models.FloatField()
    liveness = models.FloatField()
    valence = models.FloatField()
    tempo = models.FloatField()
    season = models.CharField(max_length=255)

    def __str__(self):
        return f"{self.title} by {self.artist}"



class Pool(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()

    def __str__(self):
        return self.name


class MonModele(models.Model):
    image = models.FileField(upload_to='media/images/')

    def __str__(self):
        return f"Image {self.pk}"