# views.py
from django.shortcuts import render
from .forms import FilterForm, SearchForm
import pandas as pd
import os
import numpy as np
import pandas as pd
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Song
from sklearn.preprocessing import OneHotEncoder

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

# monapp/views.py
from django.shortcuts import render
from .models import MonModele


def visualiser(request):
    # Obtenez le chemin absolu du fichier CSV
    csv_path = os.path.join(os.path.dirname(__file__), 'data', 'spotify_songs.csv')

    # Lisez le fichier CSV en utilisant l'encodage UTF-8
    my_dataframe = pd.read_csv(csv_path, encoding='utf-8')

    my_dataframe = my_dataframe[['track_id', 'track_name', 'track_artist', 'track_popularity', 'track_album_id', 'track_album_name', 'track_album_release_date', 'danceability', 'energy', 'key', 'loudness', 'mode','speechiness','acousticness','instrumentalness','liveness','valence','tempo','duration_ms']].drop_duplicates()


    # Initialisez les formulaires avec les donn�es de la requ�te POST s'il y en a
    filter_form = FilterForm(request.POST or None)
    search_form = SearchForm(request.POST or None)

    # V�rifiez quel formulaire est soumis
    if 'filter_submit' in request.POST:
        # Le formulaire de filtre est soumis
        if filter_form.is_valid():
            filters = {field: filter_form.cleaned_data.get(field) for field in filter_form.fields}
            for field, show_column in filters.items():
                if show_column:
                    pass
                else:
                    my_dataframe = my_dataframe.drop(columns=[field])
    
    elif 'search_submit' in request.POST:
        # Le formulaire de recherche est soumis
        if search_form.is_valid():
            track_id = search_form.cleaned_data.get('track_id')
            track_name = search_form.cleaned_data.get('track_name')
            track_artist = search_form.cleaned_data.get('track_artist')
            popularity = search_form.cleaned_data.get('popularity')

            # Appliquez la logique de recherche
            if track_id:
                my_dataframe = my_dataframe[my_dataframe['track_id'] == track_id]

            if track_name:
                my_dataframe = my_dataframe[my_dataframe['track_name'] == track_name]
            
            if track_artist:
                my_dataframe = my_dataframe[my_dataframe['track_artist'] == track_artist]

            if popularity:
                my_dataframe = my_dataframe[my_dataframe['track_popularity'] == popularity]

    # Obtenez les premi�res lignes du DataFrame filtr�
    filtered_rows = my_dataframe.head(100)

    # Obtenez la liste des colonnes du DataFrame filtr�
    columns = filtered_rows.columns.tolist()

    # Convertissez le DataFrame filtr� en HTML pour l'afficher dans la page
    html_table = filtered_rows.to_html(index=False, classes='table table-striped', table_id='myTable')

    # Renvoyez le HTML et les formulaires dans le template
    return render(request, 'visualiser.html', {'html_table': html_table, 'filter_form': filter_form, 'search_form': search_form, 'columns': columns})

def index(request):
    # Votre logique de vue ici
    objet_image = MonModele.objects.first()

    return render(request, 'index.html',{'objet_image': objet_image})

def test(request):
    # Votre logique de vue ici
    return render(request, 'test.html')

def notebook(request):
    # Votre logique de vue ici
    return render(request, 'notebook.html')



def prediction(request):
    variable = "toto"

    if request.method == 'POST':

        csv_path = os.path.join(os.path.dirname(__file__), 'data', 'spotify_songs.csv')
        # Lisez le fichier CSV en utilisant l'encodage UTF-8
        dataset = pd.read_csv(csv_path, encoding='utf-8')
        data_clean = dataset
        data_clean.rename(columns={"track_id" : "Id","track_name" : "Name","track_artist" : "Artist","track_popularity" : "Popularity","track_album_id" : "Album","track_album_name" : "Album Name","track_album_release_date" : "Date","playlist_name" : "Playlist Name","playlist_id" : "Playlist Id","playlist_genre" : "Playlist Genre","playlist_subgenre" : "Playlist Sub-Genre","danceability" : "Danceability","energy" : "Energy","key" : "Key","loudness" : "Loudness","mode" : "Mode","speechiness" : "Speechiness","acousticness" : "Acousticness","instrumentalness" : "Instrumentalness","liveness" : "Liveness","valence" : "Valence","tempo" : "Tempo","duration_ms" : "Duration"},inplace=True)
        data_clean.dropna(subset= ["Name"], inplace=True)
        # S�lectionner les colonnes qui doivent �tre encod�es avec des flags (0 ou 1)
        columns_to_encode = ['Playlist Genre', 'Playlist Sub-Genre']
        # Appliquer la m�thode get_dummies pour chaque colonne
        data_clean = pd.get_dummies(data_clean, columns=columns_to_encode)
        data_clean[['Danceability', 'Energy', 'Key', 'Loudness', 'Mode', 'Speechiness', 'Acousticness', 'Instrumentalness', 'Liveness', 'Valence', 'Tempo', 'Duration','Popularity']]
        data_clean['Popularity_Label'] = data_clean['Popularity'].apply(lambda x: 1 if x > 75 else 0)
        X = data_clean[['Danceability', 'Energy', 'Key', 'Loudness', 'Mode','Speechiness', 'Acousticness', 'Instrumentalness', 'Liveness', 'Valence', 'Tempo', 'Duration']]
        y = data_clean['Popularity_Label']
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        model = RandomForestClassifier()

        # Entra�ner le mod�le sur l'ensemble d'entra�nement
        model.fit(X_train, y_train)

        score = model.score(X_test, y_test)
        # Get the user input from the form
        song_title = request.POST['song_title']
        song_artist = request.POST['song_artist']
        song_date = request.POST['song_date']
        song_duration = float(request.POST['song_duration'])
        song_genre = request.POST['song_genre']
        song_subgenre = request.POST['song_subgenre']
        danceability = float(request.POST['danceability'])
        energy = float(request.POST['energy'])
        key = float(request.POST['key'])
        loudness = float(request.POST['loudness'])
        mode = float(request.POST['mode'])
        speechiness = float(request.POST['speechiness'])
        acousticness = float(request.POST['acousticness'])
        instrumentalness = float(request.POST['instrumentalness'])
        liveness = float(request.POST['liveness'])
        valence = float(request.POST['valence'])
        tempo = float(request.POST['tempo'])

                # Create a new Song object with the user input
        new_song = Song(
            title=song_title,
            artist=song_artist,
            date=song_date,
            duration=song_duration,
            genre=song_genre,
            subgenre=song_subgenre,
            danceability=danceability,
            energy=energy,
            key=key,
            loudness=loudness,
            mode=mode,
            speechiness=speechiness,
            acousticness=acousticness,
            instrumentalness=instrumentalness,
            liveness=liveness,
            valence=valence,
            tempo=tempo,
        )

                # Save the new song to the database
        #new_song.save()

        # Extract the features from the new song
        features = [
            new_song.danceability,
            new_song.energy,
            new_song.key,
            new_song.loudness,
            new_song.mode,
            new_song.speechiness,
            new_song.acousticness,
            new_song.instrumentalness,
            new_song.liveness,
            new_song.valence,
            new_song.tempo,
            new_song.duration,
            # Add season and genre/subgenre one-hot encoding here
        ]

        predicted_popularity = model.predict([features])[0]

        # Return the predicted popularity score to the template
        return render(request, 'prediction.html', {
            'song_title' : new_song.title,
            'song_artist' : new_song.artist,
            'song_date' : new_song.date,
            'song_subgenre' : new_song.subgenre,
            'song_genre' : new_song.genre,
            'song_duration' : new_song.duration, 
            'features' : features, 
            'predicted_popularity' : predicted_popularity,
            'score' : score
        })
        
    else:
        return render(request, 'prediction.html' , {'variable': variable})

