# monapp/urls.py
from django.urls import path
from . import views  

urlpatterns = [
    path('', views.index, name='index'),
    path('visualiser/', views.visualiser, name='visualiser'),
    path('notebook/', views.notebook, name='notebook'),
    path('prediction/', views.prediction, name='prediction'),
    path('test/', views.test, name='test'),
]
